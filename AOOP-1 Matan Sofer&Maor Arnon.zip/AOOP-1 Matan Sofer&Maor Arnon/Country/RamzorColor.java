//* Authors: Maor Arnon (ID: 205974553) and Matan Sofer (ID:208491811)
package Country;

public enum RamzorColor  // enum colors 
{
	
	Green,Yellow,Orange,Red;

}
